I am using Python 3.9 installed on the QMUL server that is provided to master students.

There is a zip file on this link (https://qmulprod-my.sharepoint.com/:f:/g/personal/ec22146_qmul_ac_uk/EumvpxlMOepLr4H_O9QirQAB-lBLQQFWV2wiH_z9voXylA?e=6bSgqj) named: greyenv.zip, Unzip it, and then activate this environment before you try to execute the code.

If you cannot perform the previous step, there is a requirements.txt file attached in the current folder, install these exact packages.

Thanks,
Gargeya (Grey)