Hi,
This is Gargeya Sharma 220278025 ec22146 from MSc Artificial Intelligence. This folder is my supporting material for my Dissertation titled: Unsupervised multimodal machine translation using
visual signals as rewards for reinforcement learning

These folders: 
Virtual Environment to run the code
Final Trained Models
Dataset

contain their separate README.txt files, please read them as soon as you access them. I hope I have made everything simpler to understand and reproduce in case you need to.


For any queries, drop me an email at ec22146@qmul.ac.uk or gargeya.sharma@gmail.com


With regards,
Have a good day,
Gargeya Sharma (220278025)