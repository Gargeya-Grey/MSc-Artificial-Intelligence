The link provided here gives access to the log files that were generated while I ran experiments on my model. I hope they will be enough proof to justify the amount of efforts I put in this product.


The link of the logs: https://qmulprod-my.sharepoint.com/:f:/g/personal/ec22146_qmul_ac_uk/EhOuxMmrhZ1Mqza3rl6zBPkBE7nXH-lY3nJ96FyDD3J7Pw?e=CHBghl

The link of the portal where you can visualize some the runs because the earlier runs are deleted due to low memory on the free account of weights and biases: https://wandb.ai/gargeya/trl/table?workspace=user-grey8magic