Although It is not allowed for you to have these images because I took permission through the link provided in the paper and I didn't mention that I will be sharing the images with you. Please request the images from that same link before using the images that I am going to provide for your reference to assess this dissertation.

Here is the link to .zip file of these images, unzip them in the current working directory of the code and also run the markdown cell with the command: "! git clone https://github.com/multi30k/dataset.git" by changing the cell type from markdown to code.

Link: https://qmulprod-my.sharepoint.com/:f:/g/personal/ec22146_qmul_ac_uk/EkfuU6m6yJ9OtYXg2PiQR3kBkFeAfAVsvZ_8G8njIJxrYg?e=evh44c