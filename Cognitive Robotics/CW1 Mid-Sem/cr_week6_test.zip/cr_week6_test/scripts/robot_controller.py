#! /usr/bin/env python3


import numpy as np
import rospy

from cr_week6_test.msg import perceived_info, robot_info
from cr_week6_test.srv import *


def callback(data):
    rospy.wait_for_service("Bayesian_Compute")
    try:
        compute_service = rospy.ServiceProxy("Bayesian_Compute", predict_robot_expression)
        response = compute_service(data.obj_s, data.h_act, data.h_exp)
        # rospy.loginfo(response) ## For the use of debugging

        #Create a publisher to send cubic_traj_coeffs datatype message to topic: "Coeffs"
        pub = rospy.Publisher("Robot_Info", robot_info, queue_size=10)
        # Publishing response coefficient values added with start and end time variables in a required sequence
        pub.publish(robot_info(data.id, response.p_happy, response.p_sad, response.p_neutral))
        rospy.loginfo("\n\n Robot gave Expression...") #checking to see if its running during run-time
        rospy.loginfo(robot_info(data.id, response.p_happy, response.p_sad, response.p_neutral))

    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)


def robot_controller():
    rospy.init_node("Robot_Controller")
    rospy.Subscriber("Perceived_data", perceived_info, callback)
    rospy.spin()

if __name__ == "__main__":
    robot_controller()