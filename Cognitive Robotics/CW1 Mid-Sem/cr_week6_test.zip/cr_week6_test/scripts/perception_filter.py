#! /usr/bin/env python3

import rospy
import random
from cr_week6_test.msg import human_info, object_info, perceived_info

## Global variable to deal with messages coming from two different callback functions from different topics
data_all = {"id": 0, "obj_s": 0, "h_act": 0, "h_exp": 0}

def filter_interaction(data_all):
    ## random.choice allows -> Uniformly random picking random values from the sequence provided
    r = random.choice([1,2,3,4,5,6,7,8])
    # rospy.loginfo(r)  ## Debugging
    if r in [1,4,5,7]:
        data_all["obj_s"] = 0
    if r in [2,4,6,7]:
        data_all["h_act"] = 0
    if r in [3,5,6,7]:
        data_all["h_exp"] = 0
    return data_all


## NOTE: The sequence of calling the callback functions within a single rospy.spin() is not fixed by default
#        So, I used programming skills to parallely work with them and provide sync among them, hence
#        both the callbacks looks similar in the way they are working
def callback_h(data):
    # rospy.loginfo("Called the human")  ## Debugging
    if len(data_all) == 4:
        data_all.clear()
        data_all["id"] = data.id
        data_all["h_exp"] = data.h_exp
        data_all["h_act"] = data.h_act
    elif data_all["id"] == data.id:
        data_all["h_exp"] = data.h_exp
        data_all["h_act"] = data.h_act

        # rospy.loginfo("Human combined the message")  ## Debugging
        da = filter_interaction(data_all) # Perceived Data_all dictionary (Filtered)
        pub = rospy.Publisher("Perceived_data", perceived_info, queue_size=10)
        pub.publish(perceived_info(da["id"],da["obj_s"],da["h_act"],da["h_exp"]))

        rospy.loginfo("\n Combined Filtered Data: >>>>")
        rospy.loginfo(data_all)  ## Debugging

def callback_o(data):
    # rospy.loginfo("Called the object")  ## Debugging
    if len(data_all) == 4:
        data_all.clear()
        data_all["id"] = data.id
        data_all["obj_s"] = data.obj_s
    elif data_all["id"] == data.id:
        data_all["obj_s"] = data.obj_s

        # rospy.loginfo("Object combined the message")  ## Debugging
        da = filter_interaction(data_all) # Perceived Data_all dictionary (Filtered)
        pub = rospy.Publisher("Perceived_data", perceived_info, queue_size=10)
        pub.publish(perceived_info(da["id"],da["obj_s"],da["h_act"],da["h_exp"]))

        rospy.loginfo("\n Combined Filtered Data: >>>>")
        rospy.loginfo(data_all)  ## Debugging



def perception_filter():
    rospy.init_node("Filter_Perception")

    rospy.Subscriber("Obj_info_gen", object_info, callback_o)
    rospy.Subscriber("Hum_info_gen", human_info, callback_h)
    
    rospy.spin()

if __name__ == "__main__":
    try:
        perception_filter()
    except rospy.ROSInterruptException:
        pass