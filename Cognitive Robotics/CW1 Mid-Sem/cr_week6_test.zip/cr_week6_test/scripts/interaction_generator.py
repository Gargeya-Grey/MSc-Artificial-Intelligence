#! /usr/bin/env python3

import rospy
import random
from cr_week6_test.msg import object_info, human_info

def generate_interactions():
    id = 0

    ## Instantiating 2 Publisher to publish 2 different kind of messages
    pub_o = rospy.Publisher("Obj_info_gen", object_info, queue_size=10)
    pub_h = rospy.Publisher("Hum_info_gen", human_info, queue_size=10)
    rospy.init_node("Data_gen")
    rate = rospy.Rate(0.1) # Data generation cycle for once per 10 seconds (0.1 Hz)

    while not rospy.is_shutdown():
        id+=1
        obj_s = int(random.choice([1,2])) # 1 = Small, 2 = Big
        h_exp = int(random.choice([1,2,3]))  # 1 = Happy, 2 = Sad, 3 = Neutral
        h_act = int(random.choice([1,2,3]))  # 1 = Looking at the robot, 2 = Looking at the colored toy, 3 = looking away
        
        rospy.loginfo("\n-------------------------------------------------------\n Points Generated: >>>>")
        rospy.loginfo(object_info(id, obj_s))  ## Monitoring purpose
        rospy.loginfo(human_info(id, h_act, h_exp))

        pub_o.publish(object_info(id, obj_s))
        pub_h.publish(human_info(id, h_act, h_exp))

        rate.sleep()

if __name__ == "__main__":
    try:
        generate_interactions()
    except rospy.ROSInterruptException:
        pass