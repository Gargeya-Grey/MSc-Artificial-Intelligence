#! /usr/bin/env python3

from pomegranate import *
import numpy as np
import rospy

from cr_week6_test.srv import predict_robot_expression, predict_robot_expressionResponse

## Columns are in Order: 
# Human Expression,    {1: Happy, 2: Sad, 3: Neutral} 
# Human Action,        {1: Looking at the robot, 2: Looking at the colored toy, 3: Looking away}
# Object Size          {1: Small, 2: Big}
# Robot Expression     {Dependent Variable}  {"H": Happy, "S": Sad, "N": Neutral}
# Values of Conditional Probability From the Table

h_exp = DiscreteDistribution({1:1./3, 2:1./3, 3:1./3})  ## Equal chance to get either of the possible values
h_act = DiscreteDistribution({1:1./3, 2:1./3, 3:1./3})  ## Equal chance
obj_s = DiscreteDistribution({1:1./2, 2:1./2})          ## Equal chance
r_exp = ConditionalProbabilityTable(
      [[1, 1, 1, 'H', 0.8],
       [1, 1, 2, 'H', 1.0],
       [1, 2, 1, 'H', 0.8],
       [1, 2, 2, 'H', 1.0],
       [1, 3, 1, 'H', 0.6],
       [1, 3, 2, 'H', 0.8],
       [2, 1, 1, 'H', 0.0],
       [2, 1, 2, 'H', 0.0],
       [2, 2, 1, 'H', 0.0],
       [2, 2, 2, 'H', 0.1],
       [2, 3, 1, 'H', 0.0],
       [2, 3, 2, 'H', 0.2],
       [3, 1, 1, 'H', 0.7],
       [3, 1, 2, 'H', 0.8],
       [3, 2, 1, 'H', 0.8],
       [3, 2, 2, 'H', 0.9],
       [3, 3, 1, 'H', 0.6],
       [3, 3, 2, 'H', 0.7],
       [1, 1, 1, 'S', 0.2],
       [1, 1, 2, 'S', 0.0],
       [1, 2, 1, 'S', 0.2],
       [1, 2, 2, 'S', 0.0],
       [1, 3, 1, 'S', 0.2],
       [1, 3, 2, 'S', 0.2],
       [2, 1, 1, 'S', 0.0],
       [2, 1, 2, 'S', 0.0],
       [2, 2, 1, 'S', 0.1],
       [2, 2, 2, 'S', 0.1],
       [2, 3, 1, 'S', 0.2],
       [2, 3, 2, 'S', 0.2],
       [3, 1, 1, 'S', 0.3],
       [3, 1, 2, 'S', 0.2],
       [3, 2, 1, 'S', 0.2],
       [3, 2, 2, 'S', 0.1],
       [3, 3, 1, 'S', 0.2],
       [3, 3, 2, 'S', 0.2],
       [1, 1, 1, 'N', 0.0],
       [1, 1, 2, 'N', 0.0],
       [1, 2, 1, 'N', 0.0],
       [1, 2, 2, 'N', 0.0],
       [1, 3, 1, 'N', 0.2],
       [1, 3, 2, 'N', 0.0],
       [2, 1, 1, 'N', 1.0],
       [2, 1, 2, 'N', 1.0],
       [2, 2, 1, 'N', 0.9],
       [2, 2, 2, 'N', 0.8],
       [2, 3, 1, 'N', 0.8],
       [2, 3, 2, 'N', 0.6],
       [3, 1, 1, 'N', 0.0],
       [3, 1, 2, 'N', 0.0],
       [3, 2, 1, 'N', 0.0],
       [3, 2, 2, 'N', 0.0],
       [3, 3, 1, 'N', 0.2],
       [3, 3, 2, 'N', 0.1]], [h_exp, h_act, obj_s])

## All the states in our Bayesian Network
s_h_exp = State(h_exp, name="H_Exp")
s_h_act = State(h_act, name="H_Act")
s_obj_s = State(obj_s, name="Obj_S")
s_r_exp = State(r_exp, name="R_Exp")

## Initializing the Bayesian Network with the name "cr_week6_test"
model = BayesianNetwork("cr_week6_test")
model.add_states(s_h_exp, s_h_act, s_obj_s, s_r_exp)

## Creating edges (directed dependency between states): (parent, child), child dependent on parent
model.add_edge(s_h_exp, s_r_exp)
model.add_edge(s_h_act, s_r_exp)
model.add_edge(s_obj_s, s_r_exp)

## Finalize the model with all the conditional probability values provided
model.bake()


def exp_predict(req):
    rospy.loginfo("Bayesian Network at WORK!...")
    query = {"H_Exp":req.h_exp, "H_Act":req.h_act, "Obj_S":req.obj_s}
    ## With a specific way of passing arguments in model.predict_proba, values that are not 
    # observed are absent from the query hence I removed those keys with value: 0
    if req.h_exp == 0:
        del query["H_Exp"]
    if req.h_act == 0:
        del query["H_Act"]
    if req.obj_s == 0:
        del query["Obj_S"]
    ## Breaking the structure of returned result and getting only the required robot expression probabilites
    prob = (model.predict_proba([query])[0][-1]).parameters[0]
    # rospy.loginfo(prob)  ## Debugging purpose
    return predict_robot_expressionResponse(prob["H"], prob["S"], prob["N"])

def expression_prediction():
    rospy.init_node("Robot_Brain")
    rospy.Service("Bayesian_Compute", predict_robot_expression, exp_predict)
    rospy.spin()

if __name__ == "__main__":
    expression_prediction()