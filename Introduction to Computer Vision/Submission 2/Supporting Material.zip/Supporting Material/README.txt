The code provided with the report is a jupyter notebook. 
Please import the notebook on Google Colab, 
then import the tri.jpg in the same directory and 
run the code directly cell by cell.



NOTE: 3 implementations of calculating max sensitivity of the attribution methods are commented out to save time and resources with reruns,
as Occlusion more than 2 hours to calculate and IG-SG and IG-VG require more than 12 GBs of RAM. I operated them on Colab Pro.


