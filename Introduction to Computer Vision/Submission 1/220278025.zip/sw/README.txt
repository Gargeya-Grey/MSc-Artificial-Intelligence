Python Version: Python 3.10.6

My work was developed on hub.comp-teach, Hence, you just need to run the cells in my jupyter notebooks. 
There are 5 notebooks for each question. All the solution notebooks are placed under their respective folders, 

folder name looks like: "Question _ Notebook"

Information about where to put the Dataset:
	'Dataset' named folder inside \sw folder (current folder)
		Dataset contains another folder named: DatasetA
		Dataset contains a video file: DatasetB.avi
		Dataset contains a video file: DatasetC.mpg

Images are retrived using the path: "../Dataset/DatasetA/file_path.jpg"
Videos are retrived using the path: "../Dataset/DatasetB.avi"

