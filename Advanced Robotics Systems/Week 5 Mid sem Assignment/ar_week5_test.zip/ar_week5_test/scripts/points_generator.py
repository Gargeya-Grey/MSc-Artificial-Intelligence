
#!/usr/bin/env python3
import rospy
from ar_week5_test.msg import cubic_traj_params
import random

def points_generator():
    ## Entry point of the project to generate random values for the start and end position, velocity and time
    # and publish it on the topic: Points with message type cubic_traj_params
    pub = rospy.Publisher("Points", cubic_traj_params, queue_size=10)
    rospy.init_node("points_generator")
    rate = rospy.Rate(0.05) # 1 Hz * 0.05 => 1 execution per 20 seconds
    while not rospy.is_shutdown():
        # Positions
        p0 = random.uniform(-10,10) ## For all the variables defined below this line, the range is decided to be (-10,10)
        pf = random.uniform(-10,10)
        #Velocities
        v0 = random.uniform(-10,10)
        vf = random.uniform(-10,10)
        # Time Range
        t0 = 0 # always 0 as the initial time value
        dt = random.uniform(5,10) #time step with different range than other variables above.
        tf = t0 + dt

        # rospy.loginfo(cubic_traj_params(p0,pf,v0,vf,t0,tf))   ## debugging the params values
        pub.publish(cubic_traj_params(p0,pf,v0,vf,t0,tf))
        rate.sleep()

if __name__ == '__main__':
    try:
        points_generator()
    except rospy.ROSInterruptException:
        pass


    