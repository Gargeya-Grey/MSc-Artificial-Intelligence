#! /usr/bin/env python3

import rospy
import numpy as np
from numpy.linalg import inv
from ar_week5_test.srv import compute_cubic_traj, compute_cubic_trajResponse

def handle_request(req):
    # Main processing (inputs -> outputs) point of this project
    ## To calculate the coeffs we use the equation: a = M^-1 c
    c = np.array([[req.p0],[req.v0],[req.pf],[req.vf]]) # matrix with shape: (4,1)
    M = np.array([[1, req.t0, (req.t0)**2, (req.t0)**3],
                [0, 1, 2*req.t0, 3*req.t0**2],
                [1, req.tf, req.tf**2, req.tf**3],
                [0, 1, 2*req.tf, 3*req.tf**2]]) # matrix with shape: (4,4)
    a = (inv(M)@c).squeeze()  ## Matrix multiplication with Inverse of M and c to get coeffs, shape: (4,1)
    rospy.loginfo("Service is Running... Just computed coeffs!")
    return compute_cubic_trajResponse(a[0], a[1], a[2], a[3])

def compute_server():
    # Start a new node which will act as the service provider
    rospy.init_node("computer_cubic_traj_Service")
    s = rospy.Service("compute_cubic_traj", compute_cubic_traj, handle_request)
    rospy.spin()

if __name__ == "__main__":
    compute_server()