#! /usr/bin/env python3

import rospy
import numpy as np
from ar_week5_test.msg import cubic_traj_coeffs
from std_msgs.msg import Float32

def distance(x, arr2):
    ## Equation to calculate the values of distance dependent on time
    return arr2[0] + arr2[1]*(x) + arr2[2]*(x**2) + arr2[3]*(x**3)

def velocity(x, arr2):
    ## Equation to calculate the values of velocity dependent on time
    return arr2[1] + arr2[2]*2*x + 3*arr2[3]*(x**2)

def acceleration(x, arr2):
    ## Equation to calculate the values of acceleration dependent on time
    return arr2[2]*2 + arr2[3]*6*x

def callback(data):
    arr = [data.a0, data.a1, data.a2, data.a3]
    time = [data.t0, data.tf]
    # using start time and run time to track per callback publishing time
    start_time = rospy.get_rostime()
    for t in np.arange(0,time[1], 0.0001):
        run_time = rospy.get_rostime() - start_time   ## Time difference between current time and start time to get the simulated local run time
        d = rospy.Duration.from_sec(time[1])
        if not (run_time.to_nsec() > d.to_nsec()): ## Plot the trajectories until run_time is smaller than or equal to tf.
            #rospy.loginfo(run_time.to_sec())  ## Incase you need to check if the plot is being made for tf seconds or not
            
            # Publisher to publish single floating values of distance
            pos_pub = rospy.Publisher("pos_traj", Float32, queue_size=10)
            pos_pub.publish(distance(t, arr))

            # Publisher to publish single floating values of velocity
            vel_pub = rospy.Publisher("vel_traj", Float32, queue_size=10)
            vel_pub.publish(velocity(t, arr))

            # Publisher to publish single floating values of acceleration
            acc_pub = rospy.Publisher("acc_traj", Float32, queue_size=10)
            acc_pub.publish(acceleration(t, arr))
        else:
            break

def plot_traj():
    # start a new node to plot the position, velocity and acceleration trajectories on rqt_plot
    rospy.init_node('plot_traj')
    # Subscibing to topic: Coeffs to get computed coeffs and time values to calculate 
    # position, velocity and acceleration with their equations mentioned above
    rospy.Subscriber("Coeffs", cubic_traj_coeffs, callback)
    rospy.spin()

if __name__ == "__main__":
    plot_traj()