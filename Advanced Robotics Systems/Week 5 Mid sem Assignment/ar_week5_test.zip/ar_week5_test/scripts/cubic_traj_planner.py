#!/usr/bin/env python3

import rospy
from ar_week5_test.msg import cubic_traj_params, cubic_traj_coeffs
from ar_week5_test.srv import *

def callback(data):
    # call the service with a request and get the response as coeffs
    rospy.wait_for_service("compute_cubic_traj")
    try:
        compute_service = rospy.ServiceProxy("compute_cubic_traj", compute_cubic_traj)
        response = compute_service(data.p0,data.pf,data.v0,data.vf,data.t0,data.tf)
        # rospy.loginfo(response) ## For the use of debugging

        #Create a publisher to send cubic_traj_coeffs datatype message to topic: "Coeffs"
        pub2 = rospy.Publisher("Coeffs", cubic_traj_coeffs, queue_size=10)
        # Publishing response coefficient values added with start and end time variables in a required sequence
        pub2.publish(cubic_traj_coeffs(response.a0, response.a1, response.a2, response.a3, data.t0, data.tf))
        rospy.loginfo("Coeffs Publisher Working...") #checking to see if its running during run-time

    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

def traj_planner():
    # Creating a new node with the argument as its name
    rospy.init_node('traj_planner')
    # Start a subscriber that subscribes to the topic: "Points" with message type cubic_traj_params
    # Topic is created by points_generator.py file
    rospy.Subscriber("Points", cubic_traj_params, callback)
    rospy.spin()

if __name__ == "__main__":
    try:
        traj_planner()
    except rospy.ROSInterruptException:
        pass