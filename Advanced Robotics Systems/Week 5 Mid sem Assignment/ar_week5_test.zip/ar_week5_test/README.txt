Code developed by Gargeya Sharma, QMUL
Student ID: 220278025

Commands to run the project:
-> Either run ros (version:"noetic") shell OR execute command: 'source ~/.bashrc'
-> Then we need to setup the catkin workspace with the command: 'source ~/catkin_ws/devel/setup.bash'
-> Unzip the ar_week5_test.zip file inside '~/catkin_ws/src/' directory
-> More to catkin workspace with command: 'cd ~/catkin_ws'
-> Build the catkin workspace with: 'catkin_make'
-> Move to our package: ar_week5_test with command: 'roscd ar_week5_test'
-> Execute the launch file with: 'roslaunch ar_week5_test cubic_traj_gen.launch'

The last step will start all the nodes, topics and service to complete the given task and open 2 new windows
showing rqt_graph for all the connections between the nodes and topics AND rqt_plot to show the live publishment
of three different trajectories: position, velocity and acceleration