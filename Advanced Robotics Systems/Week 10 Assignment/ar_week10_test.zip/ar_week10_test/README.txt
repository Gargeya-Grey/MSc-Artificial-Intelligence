Code developed by Gargeya Sharma, QMUL
Student ID: 220278025

Commands to run the project:
=> Download and install the following packages:
    - git clone -b ROS-DISTRO-devel https://github.con/ros-planning/moveit_tutorials.git;
    - git clone -b ROS-DISTRO-devel https://github.con/ros-planning/panda_moveit_config.git

where ROS-DISTRO is the name of your ROS distribution (eg. noetic)

Then follow these steps:
-> Either run ros (version:"noetic") shell OR execute command: 'source ~/.bashrc'
-> Then we need to setup the catkin workspace with the command: 'source ~/catkin_ws/devel/setup.bash'
-> Unzip the ar_week10_test.zip file inside '~/catkin_ws/src/' directory
-> More to catkin workspace with command: 'cd ~/catkin_ws'
-> Build the catkin workspace with: 'catkin_make'
-> Move to our package: ar_week10_test with command: 'roscd ar_week5_test'
-> Run these commands in 4 different terminals:
    - roslaunch panda_moveit_config demo.launch
    - rosrun ar_week10_test sqaure_size_generator.py
    - rosrun ar_week10_test move_panda_square.py
    - rosrun rqt_plot rqt_plot
