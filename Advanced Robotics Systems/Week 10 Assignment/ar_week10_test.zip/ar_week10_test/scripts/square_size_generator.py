
#!/usr/bin/env python3

import rospy
from ar_week10_test.msg import square_size
import random

def square_size_generator():
    pub = rospy.Publisher("sq_size", square_size, queue_size=10)
    rospy.init_node("sq_size_generator")
    rate = rospy.Rate(0.05) # 1 Hz * 0.05 => 1 execution per 20 seconds
    while not rospy.is_shutdown():
        sq_size = random.uniform(0.05,0.20)
        rospy.loginfo(sq_size)
        pub.publish(square_size(sq_size))
        rate.sleep()

if __name__ == '__main__':
    try:
        square_size_generator()
    except rospy.ROSInterruptException:
        pass 