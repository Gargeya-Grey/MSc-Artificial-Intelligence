#!/usr/bin/env python3

import rospy
import sys
import copy
import moveit_commander
import moveit_msgs
from math import pi
from ar_week10_test.msg import square_size


def callback(data):
    moveit_commander.roscpp_initialize(sys.argv)
    robot = moveit_commander.RobotCommander()
    group_name = "panda_arm"
    move_group = moveit_commander.MoveGroupCommander(group_name)
    display_trajectory_publisher = rospy.Publisher("/move_group/display_planned_path", moveit_msgs.msg.DisplayTrajectory, queue_size=1)
    joint_goal = move_group.get_current_joint_values()
    joint_goal[0] = 0
    joint_goal[1] = -pi/4
    joint_goal[2] = 0
    joint_goal[3] = -pi/2
    joint_goal[4] = 0
    joint_goal[5] = pi/3
    joint_goal[6] = 0

    move_group.go(joint_goal, wait=True)
    move_group.stop()

    waypoints = []
    wpose = move_group.get_current_pose().pose
    wpose.position.x += data.square_size
    waypoints.append(copy.deepcopy(wpose))
    wpose.position.y += data.square_size
    waypoints.append(copy.deepcopy(wpose))
    wpose.position.x -= data.square_size
    waypoints.append(copy.deepcopy(wpose))
    wpose.position.y -= data.square_size
    waypoints.append(copy.deepcopy(wpose))

    rospy.loginfo("\n-------------------------------------------\n Planning Trajectory\n-------------------------------------------\n\n")
    (plan, fraction) = move_group.compute_cartesian_path(
        waypoints, 0.01, 0.0
    )
    rospy.loginfo("\n-------------------------------------------\n Displaying Trajectory\n-------------------------------------------\n\n")
    display_trajectory = moveit_msgs.msg.DisplayTrajectory()
    display_trajectory.trajectory_start = robot.get_current_state()
    display_trajectory.trajectory.append(plan)
    display_trajectory_publisher.publish(display_trajectory)

    rospy.loginfo("\n-------------------------------------------\n Executing Plan\n-------------------------------------------\n\n")
    move_group.execute(plan, wait=True)
    move_group.stop()
    rospy.loginfo("\n-------------------------------------------\n Waiting for Next Square Size...\n-------------------------------------------")



def get_square_size():
    # Creating a new node with the argument as its name
    rospy.init_node("move_panda_square")
    # Start a subscriber that subscribes to the topic: "sq_size" with message type square_size
    # Topic is created by square_size_generator.py file
    rospy.Subscriber("sq_size", square_size, callback)
    rospy.spin()

if __name__ == "__main__":
    try:
        get_square_size()
    except rospy.ROSInterruptException:
        pass