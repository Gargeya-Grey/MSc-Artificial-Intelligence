AI Coursework 2

For Question 2, there is no code to run
For Question 3, Use the Jupyter Notebook named "Gargeya 220278025 AI Coursework 2 Notebook.ipynb"

Run the Notebook cell by cell from the start and It is good to go.


NOTE:  If the GPU doesn't work or you might see errors related to CUDA run out of memory or something other related to CUDA,
	You can set the "cuda:1" --> "cuda:0" in the cell where 'device' variable is being declared.